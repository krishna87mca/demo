<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAdhocTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('adhoc', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('contractor_id')->unsigned()->nullable();
            $table->foreign('contractor_id')->references('id')->on('contractor')->nullable();
            $table->integer('site_id')->unsigned()->nullable();
            $table->foreign('site_id')->references('id')->on('site')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->text('location')->nullable();
            $table->text('action')->nullable();
            $table->dateTime('start_date')->nullable();
            $table->time('start_time')->nullable();
            $table->dateTime('end_date')->nullable();
            $table->time('end_time')->nullable();
            $table->string('po')->nullable();
            $table->float('amount')->nullable();
            $table->text('description')->nullable();
            $table->integer('authority_id')->unsigned()->nullable();
            $table->foreign('authority_id')->references('id')->on('authority')->nullable();
            $table->dateTime('requested_at')->nullable();
            $table->integer('staff_id')->unsigned()->nullable();
            $table->foreign('staff_id')->references('id')->on('staff')->nullable();
            $table->string('staff_signature')->nullable();
            $table->integer('work_order_status_id')->unsigned()->nullable(); 
            $table->foreign('work_order_status_id')->references('id')->on('work_order_status')->nullable();
            $table->text('remarks')->nullable();
            $table->tinyInteger('status')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('adhoc');
    }
}
