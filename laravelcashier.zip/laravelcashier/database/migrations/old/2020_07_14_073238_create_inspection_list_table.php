<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInspectionListTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('inspection_list', function (Blueprint $table) {
           $table->increments('id');
            $table->integer('inspection_list_master_id')->unsigned()->nullable(); 
            //$table->foreign('inspection_list_master_id')->references('id')->on('inspection_list_master')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->string('inspection_unique_id')->unique();
            $table->integer('contractor_id')->unsigned()->nullable(); 
            $table->foreign('contractor_id')->references('id')->on('contractor')->nullable();

            $table->integer('site_id')->unsigned()->nullable();
            $table->foreign('site_id')->references('id')->on('site')->nullable();

            $table->integer('category_id')->unsigned()->nullable(); 
            $table->foreign('category_id')->references('id')->on('inspection_category')->nullable();

            $table->integer('sub_category_id')->unsigned()->nullable(); 
            $table->foreign('sub_category_id')->references('id')->on('inspection_sub_category')->nullable();

            $table->integer('group_id')->unsigned()->nullable(); 
            $table->foreign('group_id')->references('id')->on('inspection_group')->nullable();

            $table->integer('sub_group_id')->unsigned()->nullable(); 
            $table->foreign('sub_group_id')->references('id')->on('inspection_sub_group')->nullable();

            $table->string('location')->nullable();
            $table->string('check_list')->nullable();

            $table->integer('authority_id')->unsigned()->nullable(); 
            $table->foreign('authority_id')->references('id')->on('authority')->nullable();
            $table->string('authority_signature')->nullable();

            $table->integer('staff_id')->unsigned()->nullable(); 
            $table->foreign('staff_id')->references('id')->on('staff')->nullable();
            $table->string('staff_signature')->nullable();
            $table->integer('rating')->unsigned()->nullable(); 
            $table->integer('rating_out_of')->unsigned()->nullable(); 
            $table->text('remarks')->nullable();
            $table->tinyInteger('is_applied')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('inspection_list');
    }
}
