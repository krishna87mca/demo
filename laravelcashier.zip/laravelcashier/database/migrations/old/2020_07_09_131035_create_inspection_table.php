<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInspectionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('inspection', function (Blueprint $table) {
           $table->increments('id');

            $table->integer('contractor_id')->unsigned()->nullable(); 
            $table->foreign('contractor_id')->references('id')->on('contractor')->nullable();

            $table->integer('site_id')->unsigned()->nullable();
            $table->foreign('site_id')->references('id')->on('site')->nullable();

            $table->integer('category_id')->unsigned()->nullable(); 
            $table->foreign('category_id')->references('id')->on('inspection_category')->nullable();

            $table->integer('sub_category_id')->unsigned()->nullable(); 
            $table->foreign('sub_category_id')->references('id')->on('inspection_sub_category')->nullable();

            $table->integer('group_id')->unsigned()->nullable(); 
            $table->foreign('group_id')->references('id')->on('inspection_group')->nullable();

            $table->integer('sub_group_id')->unsigned()->nullable(); 
            $table->foreign('sub_group_id')->references('id')->on('inspection_sub_group')->nullable();
            $table->string('location',3000)->nullable();
            $table->string('check_list',3000)->nullable();
            $table->integer('sortorder')->unsigned()->nullable();
            $table->tinyInteger('status')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('inspection');
    }
}
