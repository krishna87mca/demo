<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateIncidentTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('incident', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('site_id')->unsigned()->nullable(); 
            $table->foreign('site_id')->references('id')->on('site')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->integer('incident_status_id')->unsigned()->nullable(); 
            $table->foreign('incident_status_id')->references('id')->on('incident_status')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->string('incident_location')->nullable();
            $table->dateTime('incident_date')->nullable();
            $table->dateTime('incident_time')->nullable();
            $table->tinyInteger('employee_injured')->nullable();
            $table->tinyInteger('third_party_injured')->nullable();
            $table->tinyInteger('third_party_property_damaged')->nullable();
            $table->longText('incident_details')->nullable();
            $table->longText('action_taken')->nullable();
            $table->string('submitted_staff_id')->nullable();
            $table->string('submitted_authority_id')->nullable();
            $table->string('contractor_id')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('incident');
    }
}
