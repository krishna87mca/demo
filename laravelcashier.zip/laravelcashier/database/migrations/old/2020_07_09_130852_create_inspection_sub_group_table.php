<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInspectionSubGroupTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('inspection_sub_group', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('contractor_id')->unsigned()->nullable(); 
            $table->integer('site_id')->unsigned()->nullable();
            $table->integer('category_id')->unsigned()->nullable(); 
            $table->integer('sub_category_id')->unsigned()->nullable(); 
            $table->integer('group_id')->unsigned()->nullable(); 
            $table->foreign('group_id')->references('id')->on('inspection_group')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->string('sub_group_name')->nullable();
            $table->integer('sortorder')->unsigned()->nullable();
            $table->tinyInteger('status')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('inspection_sub_group');
    }
}
