<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAttendanceTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('attendance', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('contractor_id')->unsigned()->nullable();
            $table->foreign('contractor_id')->references('id')->on('contractor')->nullable();
            $table->integer('site_id')->unsigned()->nullable();
            $table->foreign('site_id')->references('id')->on('site')->nullable();
            $table->string('shift_id')->nullable();
            $table->integer('staff_id')->unsigned()->nullable();
            $table->foreign('staff_id')->references('id')->on('staff')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->dateTime('shift_start_at', 0);
            $table->dateTime('shift_end_at', 0);
            $table->time('shift_start_at_time', 0);
            $table->time('shift_end_at_time', 0);
            $table->dateTime('shift_start_at_p', 0);
            $table->dateTime('shift_end_at_a', 0);
            $table->string('capture_image')->nullable();
            $table->string('capture_image_out')->nullable();
            $table->dateTime('in_at', 0);
            $table->time('in_time', 0);
            $table->decimal('in_long', 10, 7);
            $table->decimal('in_lat', 10, 7);
            $table->dateTime('out_at', 0);
            $table->time('out_time', 0);
            $table->decimal('out_long', 10, 7);
            $table->decimal('out_lat', 10, 7);
            $table->string('address')->nullable();
            $table->string('out_address')->nullable();
            $table->integer('updated_by')->unsigned()->nullable(); 
            $table->string('attendance_in_type')->nullable();
            $table->string('attendance_out_type')->nullable();
            $table->string('attendance_unique_id')->nullable();
            $table->string('is_completed')->nullable();
            $table->string('staff_deploy_location')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('attendance');
    }
}
