<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWorkOrderListTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('work_order_list', function (Blueprint $table) {
            $table->increments('id');
            $table->string('work_order_unique_id')->unique();
            $table->integer('contractor_id')->unsigned()->nullable(); 
            $table->foreign('contractor_id')->references('id')->on('contractor')->nullable();

            $table->integer('site_id')->unsigned()->nullable();
            $table->foreign('site_id')->references('id')->on('site')->nullable();

            $table->integer('category_id')->unsigned()->nullable(); 
            $table->foreign('category_id')->references('id')->on('work_order_category')->nullable();

            $table->integer('sub_category_id')->unsigned()->nullable(); 
            $table->foreign('sub_category_id')->references('id')->on('work_order_sub_category')->nullable();

            $table->integer('group_id')->unsigned()->nullable(); 
            $table->foreign('group_id')->references('id')->on('work_order_group')->nullable();

            $table->integer('sub_group_id')->unsigned()->nullable(); 
            $table->foreign('sub_group_id')->references('id')->on('work_order_sub_group')->nullable();

            $table->string('location')->nullable();
            $table->string('action')->nullable();

            $table->integer('work_order_frequency_id')->unsigned()->nullable(); 
            $table->foreign('work_order_frequency_id')->references('id')->on('work_order_frequency')->nullable();

            $table->integer('work_order_status_id')->unsigned()->nullable(); 
            $table->foreign('work_order_status_id')->references('id')->on('work_order_status')->nullable();

            $table->integer('staff_id')->unsigned()->nullable(); 
            $table->foreign('staff_id')->references('id')->on('staff')->nullable();
            $table->text('remarks')->nullable();
            $table->dateTime('due_date')->nullable();
            $table->dateTime('completed_at')->nullable();
            $table->decimal('lat')->nullable();
            $table->decimal('long')->nullable();
            $table->string('address')->nullable();
            $table->integer('workorder_id')->nullable();
            $table->dateTime('actual_date')->nullable();
            $table->integer('is_active')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('work_order_list');
    }
}
