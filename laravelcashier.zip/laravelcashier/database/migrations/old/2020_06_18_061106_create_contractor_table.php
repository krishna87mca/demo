<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateContractorTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('contractor', function (Blueprint $table) {
            $table->increments('id');
            $table->string('contractor_name')->nullable();
            $table->string('company_uen',100)->nullable();
            $table->string('gst_registration_no',100)->nullable();
            $table->date('contract_start_date')->nullable();
            $table->date('contract_end_date')->nullable();
            $table->string('address',500)->nullable();
            $table->string('phone_no',100)->nullable();
            $table->string('mobile_no',100)->nullable();
            $table->string('email_id',100)->nullable();
            $table->string('fax',100)->nullable();
            $table->string('website',255)->nullable();
            $table->string('contractor_logo',255)->nullable();
            $table->string('username',255)->nullable();
            $table->string('password',255)->nullable();
            $table->string('original_password',255)->nullable();
            $table->string('android_token',255)->nullable();
            $table->string('remember_token',255)->nullable();
            $table->integer('active_sites')->nullable();
            $table->tinyInteger('status')->nullable();
            $table->tinyInteger('is_delete')->nullable();
            $table->string('google_auth_secret')->nullable();
            $table->string('google_auth_qrcode')->nullable();
            $table->string('two_way')->nullable();
            $table->timestamps();
           
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('contractor');
    }
}
