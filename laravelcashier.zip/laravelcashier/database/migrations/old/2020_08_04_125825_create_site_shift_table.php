<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSiteShiftTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('site_shift', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('contractor_id')->unsigned()->nullable(); 
            $table->foreign('contractor_id')->references('id')->on('contractor')->nullable();
            $table->integer('site_id')->unsigned()->nullable();
            $table->foreign('site_id')->references('id')->on('site')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->string('shift_name')->nullable();
            $table->time('from_time');
            $table->time('to_time');
            $table->tinyInteger('status')->nullable();
            $table->integer('sortorder')->nullable();
            $table->dateTime('prepend_time')->nullable();
            $table->time('append_time')->nullable();
            $table->string('prepend')->nullable();
            $table->dateTime('to_time_extend')->nullable();
            $table->string('append')->nullable();

            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('site_shift');
    }
}
