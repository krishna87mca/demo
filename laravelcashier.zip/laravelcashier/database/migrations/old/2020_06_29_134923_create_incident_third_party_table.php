<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateIncidentThirdPartyTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('incident_third_party', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('incident_id')->unsigned()->nullable(); 
            $table->foreign('incident_id')->references('id')->on('incident')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->string('third_party_name')->nullable();
            $table->string('third_party_contactno')->nullable();
            $table->string('witness_name')->nullable();
            $table->string('witness_contactno')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('incident_third_party');
    }
}
