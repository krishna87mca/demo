<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSiteTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('site', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('contractor_id')->unsigned()->nullable(); 
            $table->foreign('contractor_id')->references('id')->on('contractor')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->string('subscription_id')->nullable();
            $table->integer('site_type_id')->unsigned()->nullable(); 
            $table->foreign('site_type_id')->references('id')->on('site_type')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->string('site_name')->nullable();
            $table->string('site_short_name',50)->nullable();
            $table->string('site_code',10)->nullable();
            $table->date('start_date')->nullable();
            $table->date('end_date')->nullable();
            $table->date('grace_date')->nullable();
            $table->integer('rating_per_checklist')->unsigned(); 
            $table->integer('inspection_passed')->unsigned();
            $table->integer('inspection_upload_file_count')->unsigned();  
            $table->integer('work_order_before_upload_file_count')->unsigned();  
            $table->integer('work_order_inprogress_upload_file_count')->unsigned();  
            $table->integer('work_order_completed_upload_file_count')->unsigned();    
            $table->tinyInteger('status')->nullable();
            $table->tinyInteger('is_delete')->nullable();
            $table->integer('subscription_ids')->nullable();
            $table->string('subscription_name')->nullable();
            $table->integer('contractor_subscription_id')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('site');
    }
}