<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateScheduleTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('work_order_schedule', function (Blueprint $table) {
           $table->increments('id');
            $table->integer('contractor_id')->unsigned()->nullable();
            $table->foreign('contractor_id')->references('id')->on('contractor')->nullable();
            $table->integer('site_id')->unsigned()->nullable();
            $table->foreign('site_id')->references('id')->on('site')->nullable();
            $table->integer('workorder_id')->unsigned()->nullable();
            $table->foreign('workorder_id')->references('id')->on('work_order')->nullable();
            $table->integer('work_order_frequency_id')->unsigned()->nullable();
            $table->foreign('work_order_frequency_id')->references('id')->on('work_order_frequency')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->dateTime('start_date')->nullable();
            $table->time('start_time')->nullable();
            $table->dateTime('end_date')->nullable();
            $table->time('end_time')->nullable();
            $table->integer('no_of_times')->unsigned()->nullable();
            $table->dateTime('original_scheduled_date')->nullable();
            $table->integer('grace_days_prepend')->unsigned()->nullable();
            $table->integer('grace_days_append')->unsigned()->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('work_order_schedule');
    }
}
