<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateModulesSubtitleTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('modules_subtitle', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('main_title_id')->unsigned()->nullable(); 
            $table->foreign('main_title_id')->references('id')->on('modules_title')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->string('module_subtitle')->nullable();
            $table->string('group_title')->nullable();
            $table->integer('sortorder')->unsigned()->nullable();
            $table->tinyInteger('status')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('modules_subtitle');
    }
}
