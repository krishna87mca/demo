<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAdhocWorkOrderAttachmentTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('adhoc_work_order_attachment', function (Blueprint $table) {
           $table->increments('id');
            $table->integer('contractor_id')->unsigned()->nullable(); 
            $table->foreign('contractor_id')->references('id')->on('contractor')->nullable();
            $table->integer('site_id')->unsigned()->nullable();
            $table->foreign('site_id')->references('id')->on('site')->nullable();
            $table->integer('adhoc_id')->unsigned()->nullable();
            $table->foreign('adhoc_id')->references('id')->on('adhoc')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->integer('work_order_status_id')->unsigned()->nullable();
            $table->foreign('work_order_status_id')->references('id')->on('work_order_status')->nullable();
            $table->string('attachment')->nullable();
            $table->integer('uploaded_by')->unsigned()->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('adhoc_work_order_attachment');
    }
}
