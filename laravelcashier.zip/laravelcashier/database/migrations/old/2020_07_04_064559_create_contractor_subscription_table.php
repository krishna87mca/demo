<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateContractorSubscriptionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('contractor_subscription', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('contractor_id')->unsigned()->nullable(); 
            $table->foreign('contractor_id')->references('id')->on('contractor')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->string('subscription_id')->unique();
            $table->date('subscription_from')->nullable();
            $table->date('subscription_to')->nullable();
            $table->date('grace_peroid')->nullable();
            $table->integer('site_usage')->nullable();
            $table->string('subscription_ids')->unique();
            $table->string('subscription_name')->unique();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('contractor_subscription');
    }
}
