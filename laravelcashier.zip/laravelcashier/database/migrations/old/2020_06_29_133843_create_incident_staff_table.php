<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateIncidentStaffTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('incident_staff', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('incident_id')->unsigned()->nullable(); 
            $table->foreign('incident_id')->references('id')->on('incident')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->integer('staff_id')->unsigned()->nullable(); 
            $table->foreign('staff_id')->references('id')->on('staff')->nullable();
            $table->tinyInteger('ambulance_called')->nullable();
            $table->string('hospital_name')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('incident_staff');
    }
}
