<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAssignDeployStaffLogTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('assign_deploy_staff_log', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('user_identify')->unsigned()->nullable()->comment('1 - Administrator, 2- Contractor','3- Staff'); 
            $table->integer('updated_by')->unsigned()->nullable();
            $table->integer('contractor_id')->unsigned()->nullable(); 
            $table->foreign('contractor_id')->references('id')->on('contractor')->nullable();
            $table->integer('staff_id')->unsigned()->nullable(); 
            $table->foreign('staff_id')->references('id')->on('staff')->nullable();
            $table->integer('site_id')->unsigned()->nullable(); 
            $table->foreign('site_id')->references('id')->on('site')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->tinyInteger('page')->nullable()->comment('1 - Assign, 2- Deploy');
            $table->tinyInteger('performed_action')->nullable()->comment('1 - Assign, 2- UnAssign');
            $table->string('info')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('assign_deploy_staff_log');
    }
}
