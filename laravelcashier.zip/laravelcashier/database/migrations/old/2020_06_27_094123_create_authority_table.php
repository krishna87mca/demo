<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAuthorityTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('authority', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('contractor_id')->unsigned()->nullable(); 
            $table->foreign('contractor_id')->references('id')->on('contractor')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->integer('authority_designation_id')->unsigned()->nullable(); 
            $table->foreign('authority_designation_id')->references('id')->on('authority_designation')->nullable();
            $table->string('salutation',10)->nullable();
            $table->string('authority_name')->nullable();
            $table->string('email')->nullable();
            $table->string('email_verified_at')->nullable();
            $table->string('password')->nullable();
            $table->string('original_password')->nullable();
            $table->string('remember_token')->nullable();
            $table->string('mobile_no',100)->nullable();
            $table->string('authority_photo')->nullable();
            $table->string('authority_signature')->nullable();
            $table->dateTime('last_login')->nullable();
            $table->tinyInteger('status')->nullable();
            $table->tinyInteger('is_delete')->nullable();
            $table->string('google_auth_secret')->nullable();
            $table->string('google_auth_qrcode')->nullable();
            $table->string('two_way')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('authority');
    }
}
