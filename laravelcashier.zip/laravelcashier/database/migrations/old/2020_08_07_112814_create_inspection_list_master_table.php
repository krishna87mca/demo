<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateInspectionListMasterTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('inspection_list_master', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('contractor_id')->unsigned()->nullable();
            $table->foreign('contractor_id')->references('id')->on('contractor')->nullable();
            $table->integer('site_id')->unsigned()->nullable();
            $table->foreign('site_id')->references('id')->on('site')->nullable();
            $table->string('inspection_master_id')->unique();
            $table->integer('authority_id')->unsigned()->nullable(); 
            $table->foreign('authority_id')->references('id')->on('authority')->nullable();
            $table->string('authority_signature')->nullable();
            $table->integer('staff_id')->unsigned()->nullable(); 
            $table->foreign('staff_id')->references('id')->on('staff')->nullable();
            $table->string('staff_signature')->nullable();
            $table->decimal('long', 10, 7);
            $table->decimal('lat', 10, 7);
            $table->string('address')->nullable();
            $table->integer('got_score')->unsigned()->nullable(); 
            $table->integer('total_score')->unsigned()->nullable();
            $table->float('score_percentage')->unsigned()->nullable(); 
            $table->float('passed_percentage')->unsigned()->nullable(); 
            $table->tinyInteger('is_passed')->nullable();
            $table->string('overall_remarks',3000)->nullable();
            $table->string('authority_name')->nullable();
            $table->string('is_inspection_start')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('inspection_list_master');
    }
}
