<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStaffTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('staff', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('contractor_id')->unsigned()->nullable(); 
            $table->foreign('contractor_id')->references('id')->on('contractor')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->integer('staff_designation_id')->unsigned()->nullable(); 
            $table->foreign('staff_designation_id')->references('id')->on('staff_designation')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->string('salutation',10)->nullable();
            $table->string('staff_name')->nullable();
            $table->string('nric_fin_no',100)->nullable();
            $table->string('password')->nullable();
            $table->string('original_password')->nullable();
            $table->string('qualification',100)->nullable();
            $table->date('dob')->nullable();
            $table->integer('age')->nullable();
            $table->string('nationality',100)->nullable();
            $table->string('address',1000)->nullable();
            $table->string('mobile_no',100)->nullable();
            $table->string('email',100)->nullable();
            $table->dateTime('email_verified_at')->nullable();
            $table->date('date_of_join')->nullable();
            $table->string('staff_photo')->nullable();
            $table->string('staff_signature')->nullable();
            $table->string('attendance_qrcode',50)->nullable();
            $table->dateTime('last_login')->nullable();
            $table->tinyInteger('status')->nullable();
            $table->tinyInteger('is_delete')->nullable();
            $table->string('deviceid')->nullable();
            $table->string('platform')->nullable();
            $table->string('google_auth_secret')->nullable();
            $table->string('google_auth_qrcode')->nullable();
            $table->string('two_way')->nullable();

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('staff');
    }
}
