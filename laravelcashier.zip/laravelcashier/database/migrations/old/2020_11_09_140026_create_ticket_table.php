<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTicketTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('ticket_priority', function (Blueprint $table) {
            $table->id();
            $table->string('priority')->nullable();
            $table->integer('sortorder')->nullable();
            $table->integer('status')->nullable();
            $table->timestamps();
        });

        Schema::create('ticket_status', function (Blueprint $table) {
            $table->id();
            $table->string('ticket_status')->nullable();
            $table->integer('sortorder')->nullable();
            $table->integer('status')->nullable();
            $table->timestamps();
        });

        Schema::create('ticket', function (Blueprint $table) {
            $table->id();
            $table->string('ticket_number')->nullable();
            $table->string('subject')->nullable();
            $table->string('description')->nullable();
            $table->integer('status_id')->nullable();
            $table->integer('priority_id')->nullable();
            $table->string('contact_person')->nullable();
            $table->string('contact_number')->nullable();
            $table->string('email')->nullable();
            $table->string('created_by')->nullable();
            $table->string('contractor_id')->nullable();
            $table->string('created_via')->nullable();
            $table->timestamps();
        });

        Schema::create('ticket_attachments', function (Blueprint $table) {
            $table->id();
            $table->integer('ticket_id')->nullable();
            $table->string('attachment')->nullable();
            $table->timestamps();
        });

        Schema::create('ticket_comments', function (Blueprint $table) {
            $table->id();
            $table->integer('ticket_id')->nullable();
            $table->string('comments')->nullable();
            $table->integer('status_id')->nullable();
            $table->integer('updated_by')->nullable();
            $table->string('updated_via')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('ticket');
    }
}
