<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWorkOrderCategoryTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('work_order_category', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('contractor_id')->unsigned()->nullable(); 
            $table->integer('site_id')->unsigned()->nullable(); 
            $table->foreign('site_id')->references('id')->on('site')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->string('category_name')->nullable();
            $table->integer('sortorder')->unsigned()->nullable();
            $table->tinyInteger('status')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('work_order_category');
    }
}
