<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateWorkOrderTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('work_order', function (Blueprint $table) {
            $table->increments('id');

            $table->integer('contractor_id')->unsigned()->nullable(); 
            $table->foreign('contractor_id')->references('id')->on('contractor')->nullable();

            $table->integer('site_id')->unsigned()->nullable();
            $table->foreign('site_id')->references('id')->on('site')->nullable();

            $table->integer('category_id')->unsigned()->nullable(); 
            $table->foreign('category_id')->references('id')->on('work_order_category')->nullable();

            $table->integer('sub_category_id')->unsigned()->nullable(); 
            $table->foreign('sub_category_id')->references('id')->on('work_order_sub_category')->nullable();

            $table->integer('group_id')->unsigned()->nullable(); 
            $table->foreign('group_id')->references('id')->on('work_order_group')->nullable();

            $table->integer('sub_group_id')->unsigned()->nullable(); 
            $table->foreign('sub_group_id')->references('id')->on('work_order_sub_group')->nullable();

            $table->string('location')->nullable();
            $table->string('action')->nullable();
            $table->integer('work_order_frequency_id')->unsigned()->nullable(); 
            $table->foreign('work_order_frequency_id')->references('id')->on('work_order_frequency')->nullable()->onDelete('cascade')->onUpdate('cascade');
            $table->integer('sortorder')->unsigned()->nullable();
            $table->tinyInteger('status')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('work_order');
    }
}
