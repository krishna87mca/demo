<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class ProductSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
    	DB::table('products')->truncate();
    	 $create=[];
    	 for($i=1;$i<=15;$i++) {
    	 $amount='25.00';
    	 $data['product_name'] = 'Product '.$i;
    	 $data['amount'] = $amount+$i;
		 $create[]=$data;
    	 }
    	 

         DB::table('products')->insert($create);

    }
}
