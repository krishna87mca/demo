<!DOCTYPE html>
<html>
<head>
<title>Laravel Cashier</title>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>



<h3>
<a style="float: right;" href="<?php echo e(url('payments')); ?>">Payments</a></h3>
<br><br>
<h1 align="center">Laravel Cashier</h1>
<h2>Products</h2>
<table>
  <tr>
    <th>Product Name</th>
    <th>Price (INR)</th>
    <th>Buy Now</th>
  </tr>
  <?php foreach($products as $product){?>
  <tr>
    <td><?php echo e($product->product_name); ?></td>
    <td><?php echo e($product->amount); ?></td>
    <td><a href="<?php echo e(url('stripe_form/'.$product->id)); ?>">Buy Now</a></td>
  </tr> <?php } ?>
 
</table>

</body>
</html><?php /**PATH G:\xampp\htdocs\laravelcashier\resources\views/product.blade.php ENDPATH**/ ?>