<!DOCTYPE html>
<html>
<head>
<title>Laravel Cashier</title>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>

<h3>
<a style="float: right;" href="<?php echo e(url('product')); ?>">Back to products</a></h3>
<br><br>
<h1 align="center">Laravel Cashier</h1>
<h2>Payments</h2>


<table>
  <tr>
    <th>Product Name</th>
    <th>Price(INR)</th>
    <th>Payment ID</th>
    <th>Charge ID</th>
    <th>Balance Transaction</th>
    <th>Receipt URL</th>
  </tr>
  <?php foreach($payments as $payment){?>
  <tr>
    <td><?php echo e($payment->product_name); ?></td>
    <td><?php echo e($payment->amount); ?></td>
    <td><?php echo e($payment->payment_id); ?></td>
    <td><?php echo e($payment->charge_id); ?></td>
    <td><?php echo e($payment->balance_transaction); ?></td>
    <td><a href="<?php echo e($payment->receipt_url); ?>" target="_blank">Receipt</a></td>

  </tr> <?php } ?>
 
</table>

</body>
</html><?php /**PATH G:\xampp\htdocs\passport\resources\views/payments.blade.php ENDPATH**/ ?>