<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Staff;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        $validatedData = $request->validate([
            'staff_name' => 'required|max:55',
            'email' => 'email|required',
            'password' => 'required'
        ]);

        $validatedData['password'] = bcrypt($request->password);
        $validatedData['original_password'] = $request->password;

        $staff = Staff::create($validatedData);

        $accessToken = $staff->createToken('authToken')->accessToken;

        return response([ 'staff' => $staff, 'access_token' => $accessToken]);
    }

    public function login(Request $request)
    {
        $loginData = $request->validate([
            'email' => 'email|required',
            'password' => 'required'
        ]);

        //if (!Auth::guard('api-staff')->attempt($loginData)) {
        if(!Auth::guard('staff')->attempt(['email' => $request->email, 'password' => $request->password])){ 
            return response(['message' => 'Invalid Credentials']);
        }

        $accessToken = Auth::guard('staff')->user()->createToken('authToken')->accessToken;

        return response(['staff' => Auth::guard('staff')->user()->staff_name, 'access_token' => $accessToken]);

    }
}