<?php
namespace App\Http\Controllers\API;

use Illuminate\Http\Request; 
use App\Http\Controllers\Controller; 
use App\Http\Controllers\API\BaseController as BaseController;
use App\Authority;
use App\Staff;
use App\EmailNotifications;
use App\Myorganization;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Hash;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Support\Facades\Auth;
use App\Jobs\SendEmailJob; 
use Validator;


class UserController extends BaseController 
{
    public $successStatus = 200;
    /** 
     * login api 
     * 
     * @return \Illuminate\Http\Response 
     */ 
    public function authority_login(Request $request)
    { 
    	$validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required',
        ]);

        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());       
        }

        if(Auth::guard('authority')->attempt(['email' => $request->email, 'password' => $request->password])){ 
            $user = Auth::guard('authority')->user();  
            if ($user->status == 1)
            { 
                $today = date('Y-m-d');                 
                $result['token'] =  $user->createToken('tqms-authority')-> accessToken;
                $result['authority_name'] =  $user->authority_name; 
                $result['last_login'] =  $user->last_login;
                $user->last_login = date('Y-m-d H:i:s');
                $user->save();

                return $this->sendResponse($result, 'User login successfully.');
            }
            return $this->sendResponse('Unauthorised', ['error'=>'You are inactive!!!. Please contact admin']);
        } 
        else{ 
           return $this->sendError('Unauthorised', ['error'=>'Unauthorised']); 
        } 
    }

    public function staff_login(Request $request)
    {   

        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required',
        ]);

        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());       
        }

        if(Auth::guard('staff')->attempt(['email' => $request->email, 'password' => $request->password])){ 
            $user = Auth::guard('staff')->user(); 
       if ($user->staff_designation_id == 1 || $user->staff_designation_id == 2 )
            { 		
            if ($user->status == 1 )
            { 
                $today = date('Y-m-d');                 
                $result['token'] =  $user->createToken('tqms-staff')-> accessToken;
                $result['staff_name'] =  $user->staff_name;
                $result['staff_designation_id'] =  $user->staff_designation_id;
                $result['contractor_id'] =  $user->contractor_id;
                $result['two_way'] =  $user->two_way; 
                $result['google_auth_secret'] =  $user->google_auth_secret; 
				
				
                $result['last_login'] =  $user->last_login;
                $user->last_login = date('Y-m-d H:i:s');
                $user->save();

                return $this->sendResponse($result, 'User login successfully.');
            }
            return $this->sendResponse('Unauthorised', ['error'=>'You are inactive!!!. Please contact admin']);
			}
			else{
				 return $this->sendError('Unauthorised', ['error'=>'Unauthorised']); 

			}
        } 
        else{ 
           return $this->sendError('Unauthorised', ['error'=>'Unauthorised']); 
        } 
    }
public function staff_login_new(Request $request)
    {   

        $validator = Validator::make($request->all(), [
            'email' => 'required|email',
            'password' => 'required',
        ]);

        if($validator->fails()){
			return $this->sendResponse('Norecord', 'Please enter a valid email address');
            //return $this->sendError('Validation Error.', $validator->errors());       
        }

        if(Auth::guard('staff')->attempt(['email' => $request->email, 'password' => $request->password])){ 
            $user = Auth::guard('staff')->user(); 
       if ($user->staff_designation_id == 1 || $user->staff_designation_id == 2 )
            { 		
            if ($user->status == 1 )
            { 
                $today = date('Y-m-d');                 
                $result['token'] =  $user->createToken('tqms-staff')-> accessToken;
                $result['staff_name'] =  $user->staff_name;
                $result['staff_designation_id'] =  $user->staff_designation_id;
                $result['contractor_id'] =  $user->contractor_id;
                $result['two_way'] =  $user->two_way; 
                $result['google_auth_secret'] =  $user->google_auth_secret; 
				
				
                $result['last_login'] =  $user->last_login;
                $user->last_login = date('Y-m-d H:i:s');
                $user->save();

                return $this->sendResponse($result, 'User login successfully.');
            }
						return $this->sendResponse('Norecord', 'You are inactive!!!. Please contact admin');

			}
			else{
			return $this->sendResponse('Norecord', 'Please check Your Email and password');


			}
        } 
        else{ 
			return $this->sendResponse('Norecord', 'Please check Your Email and password');
        } 
    }


    public function get_staff(Request $request)
    { 
        $staff=Staff::join('staff_designation','staff_designation.id','staff.staff_designation_id')->select('staff.*','staff_designation.staff_designation')->findorfail(Auth::guard('api-staff')->user()->id);

        return $this->sendResponse($staff, 'Staff retrieved successfully.');
    }

    public function get_authority(Request $request)
    { 
        
        $authority=Authority::join('authority_designation','authority_designation.id','authority.authority_designation_id')->select('authority.*','authority_designation.authority_designation')->findorfail(Auth::guard('api-authority')->user()->id);

        return $this->sendResponse($authority, 'Staff retrieved successfully.');
    }

    public function changePasswordAuthority(Request $request)
    { 
         $validator = Validator::make($request->all(), [ 
            'current_password' => 'required', 
            'new_password' => 'required|string|min:6', 
            'new_confirm_password' => 'required|string|min:6|same:new_password',
        ]);    

        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());       
        }


        if (!(\Hash::check($request->get('current_password'),Auth::guard('api-authority')->user()->password))) 
        {
            return response()->json(['status' => "Old Password is mismatch."]); 
        }

        if(strcmp($request->get('current_password'), $request->get('new_password')) == 0)
        {
            //Current password and new password are same
            return $this->sendError('error', ['message'=>'New Password cannot be same as your current password !!!. Please choose a different password.']);             
        }    

        $user = Auth::guard('api-authority')->user();
        $user->password = bcrypt($request->get('new_password'));
        $user->original_password = $request->get('new_password');
        if ($user->save())
        {
             return $this->sendResponse(['status'=>'success'], 'Password changed sucessfully');
        }
        else
        {
            return $this->sendError('error', ['message'=>'Password changed failed !']);  
        }
    }

    public function changePasswordStaff(Request $request)
    { 
         $validator = Validator::make($request->all(), [ 
            'current_password' => 'required', 
            'new_password' => 'required|string|min:6', 
            'new_confirm_password' => 'required|string|min:6|same:new_password',
        ]);    

        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());       
        }


        if (!(\Hash::check($request->get('current_password'),Auth::guard('api-staff')->user()->password))) 
        {
            return response()->json(['status' => "Old Password is mismatch."]); 
        }

        if(strcmp($request->get('current_password'), $request->get('new_password')) == 0)
        {
            //Current password and new password are same
            return $this->sendError('error', ['message'=>'New Password cannot be same as your current password !!!. Please choose a different password.']);             
        }    

        $user = Auth::guard('api-staff')->user();
        $user->password = bcrypt($request->get('new_password'));
        $user->original_password = $request->get('new_password');
        if ($user->save())
        {
             return $this->sendResponse(['status'=>'success'], 'Password changed sucessfully');
        }
        else
        {
            return $this->sendError('error', ['message'=>'Password changed failed !']);  
        }
    }


    public function uploadAvatarAuthority(Request $request) 
    { 
        $file = $_FILES['file']['tmp_name'];
        $file_name = $_FILES['file']['name'];
        $target_path = "uploads/authority/profile";

        $explode_file_name = explode('.', $file_name);
        $file_rename = $explode_file_name[0].'_'.date('i_s').'.'.$explode_file_name[1];

        $target_path = $target_path . $file_rename;

        if(move_uploaded_file($file, $target_path)) 
        {           
            $user = Auth::guard('api-authority')->user();
            $user->authority_photo = $file_rename;
            if ($user->save())
            {                  
                return $this->sendResponse(['status'=>'success'], 'Photo uploaded sucessfully');
            }
            else
            {
                return $this->sendError('error', ['message'=>'Photo uploaded failed']); 
            }  
        }
        else
        {
           return $this->sendError('error', ['message'=>'Photo uploaded failed']); 
        }
    }


    public function uploadAvatarStaff(Request $request) 
    { 
        $file = $_FILES['file']['tmp_name'];
        $file_name = $_FILES['file']['name'];
        $target_path = "uploads/staff/profile";

        $explode_file_name = explode('.', $file_name);
        $file_rename = $explode_file_name[0].'_'.date('i_s').'.'.$explode_file_name[1];

        $target_path = $target_path . $file_rename;

        if(move_uploaded_file($file, $target_path)) 
        {           
            $user = Auth::guard('api-staff')->user();
            $user->staff_photo = $file_rename;
            if ($user->save())
            {                  
                return $this->sendResponse(['status'=>'success'], 'Photo uploaded sucessfully');
            }
            else
            {
                return $this->sendError('error', ['message'=>'Photo uploaded failed']); 
            }  
        }
        else
        {
            return $this->sendError('error', ['message'=>'Photo uploaded failed']); 
        }
    }


    public function forgotpassword(Request $request)
    {
        if ($request->isMethod('POST')) 
        {
        $validator = Validator::make($request->all(), [
            'email' => 'required|email'
        ]);

        if($validator->fails()){
            return $this->sendError('Validation Error.', $validator->errors());       
       }

        $chk = Staff::where('email','=',$request->email)->first();
    
        if(!empty($chk ) && $chk->id>0){
        $user = Staff::findOrFail($chk->id);
        
        if($user->id>0)
        {        
        $datas=array();
        $newpassword=Str::random(8);
        // $new_pass=Hash::make($newpassword);
        $datas['password'] = bcrypt($newpassword);
        $datas['original_password']= $newpassword;
         
        $user->update($datas);
        
        $emailtemplate= EmailNotifications::where('template_unique_id','FP')->first();
        $myorg= Myorganization::first();
        
        $replace_temp=array(
        '{url}' => url('/'),
        '{subject}'=>$emailtemplate->subject,  
        '{org_name}'=>$myorg->name,
        '{org_phone}'=>$myorg->phone,
        '{org_address}'=>$myorg->address,
        '{org_email}'=>$myorg->email,
        '{username}'=>$user->email,
        '{password}'=>$newpassword,
        '{login_url}'=>config('app.url').'staffpanel/login',
        '{name}'=>$user->name,
        '{email}'=>$user->email,
        );
    
        $template['message']=strtr($emailtemplate->content,$replace_temp);
        
        //$template['to_email']= 'marimuthu.e29@gmail.com';
        //$template['to_email']= 'ram@xsosys.sg';
		
		
        $template['to_email']= $user->email;
        $template['subject']= $emailtemplate->subject;
        $template['from_email']= $myorg->email;
        $template['from_name']= $myorg->name;
       
        $details['email'] = $template['to_email'];
        $details['subject'] = $template['subject'];
        $details['content'] = $template['message'];
        SendEmailJob::dispatch($details);

        return $this->sendResponse(['status'=>'success'], 'Password Sent Successfully.');

        } else {
            return $this->sendResponse('Info', ['message'=>'There are no user Found.']);
        }
        
        }else {
            return $this->sendResponse('Info', ['message'=>'There are no user Found.']);
        }
        } 
    }
        
}