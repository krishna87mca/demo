<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Laravel\Cashier\Cashier;
use App\Models\User;
use DB;

class ProductController extends Controller
{
    public function index(){ 

    	$products = DB::table('products')->get();    	
       return view('product',compact('products'));
    }
 public function purchase(){  
 $data = array('name'=>'krishna 2020','email'=>'akrishna1987mca@gmail.com','password'=>bcrypt('krishna'));
   $user = User::create($data);

 //  DB::table('users')->insert($data);
$stripeCustomer = $user->createAsStripeCustomer();


  }

   public function stripe_form($id){

    $product = DB::table('products')->where('id',$id)->first(); 
   	return view('stripe_form',compact('product'));

   }

   public function stripe_charge(Request $request){
    
   $user = User::where('id',1)->first();
   $amount = $request->amount*100;
   $payment_id = $request->payment_id;
   $stripeCharge = $user->charge(
        $amount, $payment_id
    );
     $product_id= $request->p_id;
     $product = DB::table('products')->where('id',$product_id)->first(); 

     $data['product_id'] =  $product->id;
     $data['amount'] =  $request->amount;
     $data['payment_id'] =  $stripeCharge->id;
     $data['charge_id'] =   $stripeCharge->charges->data[0]->id;
     $data['balance_transaction'] = $stripeCharge->charges->data[0]->balance_transaction;
    $data['receipt_url'] =   $stripeCharge->charges->data[0]->receipt_url;
     
      $payments = DB::table('payments')->insert($data);
      return redirect('payments?st=success&cid='.$data['charge_id']);


/*
   echo '<pre>';
   print_r($stripeCharge);*/


}


 public function payments(){ 

      $payments = DB::table('payments')->join('products','payments.product_id','products.id')->orderby('payments.id','DESC')->get();     
       return view('payments',compact('payments'));
    }


}