<?php

namespace App\Http\Middleware;

use Closure;
use App\Models\Staff;
use Auth;

class CheckIfStaff
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = 'staff')
    {

        if (\Auth::guard($guard)->check() === TRUE) 
        {

            if ('staff' === $guard) 
            {
                $staff =Staff::where('id',Auth::guard('staff')->user()->id)->first();

                return $next($request);
            }
            return redirect('/api/register');
        }

        return redirect('/api/register');
    }
}
