<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('/register', 'Api\AuthController@register');
Route::get('/login', 'Api\AuthController@login');

Route::group(['middleware' => ['auth:api-staff'], 'namespace' => 'API'], function(){
	Route::get("/new", function(){
	   return Auth::guard('api-staff')->user()->staff_name;
	});

	Route::get("/logout", function(){
	$token = Auth::guard('api-staff')->user()->token();
    $token->revoke();
    $response = ['message' => 'You have been successfully logged out!'];
    return response($response, 200);
    });
});