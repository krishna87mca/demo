<!DOCTYPE html>
<html lang="en">
<head>
<title>Laravel Cashier</title>
  <style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
  <title>TEST</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>

  
<div class="container">
  <h8>
<a style="float: right;" href="{{url('product')}}">Back to products</a></h8>
<h2>Checkout</h2>
 <form action="{{url('stripe_charge')}}" method="post" id="stripe_form" > 
  <table>
   
    <tr><td>Name</td><td><input class="form-control" id="card-holder-name" type="text"></td></tr>
    <tr><td>Product Name</td><td>{{$product->product_name }}</td></tr>
    <tr><td>Price</td><td>{{$product->amount }}
      @csrf
      <input type="hidden" name="amount" value="{{$product->amount}}">
      <input type="hidden" name="p_id" value="{{$product->id}}">
      <input type="hidden" id="stripe_token" name="payment_id" value="">
    </td></tr>
    <tr><td>Card Details</td><td> <div id="card-element" class="form-control"></div></td></tr>
    
     <tr><td>Buy Now</td><td> <button id="card-button" type="button">
    Process Payment
  
</button></td></tr>

  </table>
  </form> 
</div>

 
<!-- Stripe Elements Placeholder -->



</div>

</body>

<script src="https://js.stripe.com/v3/"></script>

<script>
    const stripe = Stripe('pk_test_51HwkvJCru1xiBMgZh2P5R7qCCnKRoVADVf1va9RTqoMgDudWX25kHRjWPblpePhSQQe9LDW0XQIZEokhVzlrmuxj00q4eUeO3f');

    const elements = stripe.elements();
    const cardElement = elements.create('card');

   

    cardElement.mount('#card-element');

    const cardHolderName = document.getElementById('card-holder-name');
const cardButton = document.getElementById('card-button');

cardButton.addEventListener('click', async (e) => {
    const { paymentMethod, error } = await stripe.createPaymentMethod(
        'card', cardElement, {
            billing_details: { name: cardHolderName.value }
        }
    );

    if (error) {
        // Display "error.message" to the user...
        alert("Error:Plase enter valid details");
        return false;
    } else {
      var id = paymentMethod.id;
      $("#stripe_token").val(id)
      $("#stripe_form").submit();
        // The card has been verified successfully...

    }
});


</script>


</html>